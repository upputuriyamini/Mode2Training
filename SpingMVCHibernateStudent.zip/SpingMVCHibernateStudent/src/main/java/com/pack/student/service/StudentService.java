package com.pack.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;




import com.pack.student.dao.StudentDao;
import com.pack.student.model.Student;

@Service
public class StudentService {
	@Autowired
	private StudentDao studentDao;
	
	
	@Transactional
	public void addStudent(Student student) {
		studentDao.addStudent(student);
		
	}
	/*@Transactional
	public List<Student> studentDetails(Student student) {
		return studentDao.studentDetails(student);*/
	/*
	 * @Transactional public List<College> studentdetails(String usn) { return
	 * studentDao.getStudentplaceDetails(usn); }
	 */


	public String getPlace(String rollno) {
		// TODO Auto-generated method stub
		return studentDao.getPlaceDetails(rollno);
	}


	
	@Transactional

	public List<Student> listStudent(Integer pageno, Integer pagesize) {
		// TODO Auto-generated method stub
		return this.studentDao.listStudent(pageno,pagesize);
	}


	@Transactional

	public List<Student> listStudent() {
		// TODO Auto-generated method stub
		return this.studentDao.listStudent();
	}


	/*public List<Student> studentdetails(Student student) {
		// TODO Auto-generated method stub
		@RequestMapping(value="/student/get", method=RequestMethod.GET )
		public Iterable<Customer> getAll( ){
			return	customerServiceImpl.getAll();
			}*/
	}


	


