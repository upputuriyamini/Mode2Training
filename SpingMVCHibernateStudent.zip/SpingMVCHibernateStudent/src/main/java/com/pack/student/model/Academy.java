package com.pack.student.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "academy")
public class Academy {
@Id
private String rollno;
private String course;
private int sem;

public String getRollno() {
	return rollno;
}
public void setRollno(String rollno) {
	this.rollno = rollno;
}
public String getCourse() {
	return course;
}
public void setCourse(String course) {
	this.course = course;
}
public int getSem() {
	return sem;
}
public void setSem(int sem) {
	this.sem = sem;
}

}
