package com.pack.student.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.pack.student.model.Student;
import com.pack.student.service.AcademyService;
import com.pack.student.service.StudentService;

import com.pack.student.model.Academy;
import com.pack.student.model.College;


@Controller
public class StudentController {
private static final Logger logger = LoggerFactory.getLogger(StudentController.class);

private static final String Academy = null;
	
	@Autowired
	private StudentService studentService;
	@Autowired
	private AcademyService academyservice;
	
	private Map<String, Student> student = null;

	public StudentController() {
		student = new HashMap<String, Student>();
	}
	
	
	@ModelAttribute("student")
	public Student createStudentModel() {
		// ModelAttribute value should be same as used in the empSave.jsp
		return new Student();
	}
	
	@RequestMapping(value = "/student/add", method = RequestMethod.GET)
	public String addStudent(Model model) {
		logger.info("Returning studentdetails.jsp page");
		return "studentdetails";
	}

	
	 @RequestMapping(value = "/student/add.do", method = RequestMethod.POST)
	public String saveStudentAction(@ModelAttribute("student") @Validated Student student, BindingResult bindingResult,
			Model model) {
	
		if (bindingResult.hasErrors()) {
			logger.info("Returning studentdetails.jsp page");
			return "studentdetails";
		}
		logger.info("Returning success.jsp page");
		model.addAttribute("student", student);
		// customers.put(customer.getEmail(), customer);
		this.studentService.addStudent(student);
		return "success";
	}
	@RequestMapping(value = "/student/save", method = RequestMethod.POST)
	public String addStudent(@ModelAttribute("student") @Validated Student student,@Validated Academy academy, BindingResult bindingResult,
			Model model) {
		//Academy academy=new Academy();
		if (bindingResult.hasErrors()) {
			logger.info("Returning studentdetails.jsp page");
			return "studentdetails/academicdetails";
		}
		logger.info("Returning success.jsp page");
		model.addAttribute("student", student);
		// customers.put(customer.getEmail(), customer);
		this.studentService.addStudent(student);
		academy.setCourse("MECH");
		academy.setSem(8);
		this.academyservice.addAcademy(academy);
		return "success";
	}
	
	@RequestMapping(value = "/details", method = RequestMethod.GET)
	public String getdetails(Student student,Model model) {
		logger.info("Returning details.jsp page");
		model.addAttribute("student", new Student());
		model.addAttribute("listStudent",this.studentService.listStudent());
		return "details";
	}
	@RequestMapping(value="/student/place/{rollno}",method=RequestMethod.GET)
	public String StudentDetails(@PathVariable(value="rollno") String rollno,@ModelAttribute("student")@Validated Student student,Model model) {
		String place=studentService.getPlace(rollno);
		model.addAttribute("place",place);
		return "place";
		
	}
	
	@RequestMapping(value = "/student/paging/{pageno,pagesize}", method = RequestMethod.GET)
	public String getPagination(
            @RequestParam(defaultValue = "5") Integer pageno,
            @RequestParam(defaultValue = "5") Integer pagesize,ModelMap model) {
		logger.info("Returning paging.jsp page");
		model.addAttribute("listStudent", studentService.listStudent(pageno,pagesize));
		return "paging";
	}
		
	}

