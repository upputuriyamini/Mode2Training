package com.pack.student.dao;

import java.util.ArrayList;
import java.util.List;



import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pack.student.model.College;
import com.pack.student.model.Student;

@Repository
public class StudentDao {

	private static final Logger logger = LoggerFactory.getLogger(StudentDao.class);

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	public void addStudent(Student student) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(student);
		logger.info("Student added successfully");
	}

	@SuppressWarnings("unchecked")

	public String getPlaceDetails(String rollno) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.openSession();
		//System.out.println("student");
		String college=rollno.substring(0, 4);
		System.out.println(college);
		String collegeplace=null;
		List<College> collegeList=new ArrayList<College>();
		collegeList=session.createQuery("from College").list();
		for(int i=0;i<collegeList.size();i++){
			if(college.equals(collegeList.get(i).getCollegecode())){
				collegeplace=collegeList.get(i).getCollegeplace();
				System.out.println(collegeplace);
			}}
			return collegeplace;
	}
	@SuppressWarnings("unchecked")
public List<Student>listStudent(){
		Session session=this.sessionFactory.getCurrentSession();
		List<Student> studentList=session.createQuery("from Student").list();
		for(Student stud:studentList){
			logger.info("Student List"+stud);
		}return studentList;
	}
	
	@SuppressWarnings("unchecked")

	public List<Student> listStudent(int pageno,int pagesize) {
		// TODO Auto-generated method stub
        Query query =  sessionFactory.getCurrentSession().createQuery("from Student");
        query.setMaxResults(5);
        query.setFirstResult(5);
        return (List<Student>)query.list();
       
	}
	}

	


