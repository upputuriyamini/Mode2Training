
package com.pack.student.controller;



	import java.util.HashMap;
	import java.util.Map;

	import org.slf4j.Logger;
	import org.slf4j.LoggerFactory;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.ui.Model;
	import org.springframework.validation.BindingResult;
	import org.springframework.validation.annotation.Validated;
	import org.springframework.web.bind.annotation.ModelAttribute;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.student.model.Academy;
import com.pack.student.model.College;
	import com.pack.student.model.Student;
import com.pack.student.service.AcademyService;
import com.pack.student.service.CollegeService;
	import com.pack.student.service.StudentService;



	@Controller
	
	public class AcademyController {
	private static final Logger logger = LoggerFactory.getLogger(AcademyController.class);
		
		@Autowired
		private AcademyService academyService;
		
		
		private Map<String, Academy> academy = null;

		public AcademyController() {
			academy = new HashMap<String, Academy>();
		}
		
		
		@ModelAttribute("academy")
		public Academy creatAcademyModel() {
			// ModelAttribute value should be same as used in the empSave.jsp
			return new Academy();
		}
		/*@RequestMapping(value = "/cust/add", method = RequestMethod.GET)
		@ResponseBody
		List<Customer> getAllCustomer(){
			return null;
		}
		
		@RequestMapping(value = "/cust/save.do", method = RequestMethod.POST)
		void saveCustomerDetails(@RequestBody Customer customer){
			
		
	}*/
		@RequestMapping(value = "/academy/add", method = RequestMethod.GET)
		public String addAcademy(Model model) {
			logger.info("Returning academicdetails.jsp page");
			// model.addAttribute("user", new User());
			return "academicdetails";
		}
		@RequestMapping(value = "/academy/save.do", method = RequestMethod.POST)
		public String saveAcademyAction(@ModelAttribute("academy") @Validated Academy academy, BindingResult bindingResult,
				Model model) {
		
			if (bindingResult.hasErrors()) {
				logger.info("Returning academicdetails.jsp page");
				return "academicdetails";
			}
			logger.info("Returning success.jsp page");
			model.addAttribute("academy", academy);
			// customers.put(customer.getEmail(), customer);
			this.academyService.addAcademy(academy);
			return "success";
		}
	}


